import React from "react";

function SettingScreen() {
  return <div>SettingScreen</div>;
}

export default SettingScreen;
