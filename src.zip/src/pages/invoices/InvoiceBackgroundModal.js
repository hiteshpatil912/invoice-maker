import React from "react";

function InvoiceBackgroundModal() {
  return <div>InvoiceBackgroundModal</div>;
}

export default InvoiceBackgroundModal;
