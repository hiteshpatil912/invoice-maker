import React from "react";
import PageTitle from "../../components/Common/PageTitle";

function AboutScreen() {
  return (
    <div>
      <div className="p-4">
        <PageTitle title="About Me" />
      </div>

    </div>
  );
}
export default AboutScreen;
